import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ??
  JSON.parse(Deno.env.get("SUPABASE_SECRET_KEYS") ?? "{}").default;
if (!serviceKey) throw new Error("Supabase service key is unavailable.");

const admin = createClient(supabaseUrl, serviceKey, {
  auth: { persistSession: false, autoRefreshToken: false }
});

type DbWebhook = {
  type: string;
  table: string;
  schema: string;
  record: {
    id: string;
    conversation_id: string;
    sender_id: string;
    sender_role: string;
    body: string;
    visibility: string;
  };
};

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  let event: DbWebhook;
  try { event = await req.json(); } catch { return new Response("Invalid JSON", { status: 400 }); }

  if (event.type !== "INSERT" || event.table !== "messages" ||
      event.schema !== "public" || event.record?.sender_role !== "customer" ||
      event.record?.visibility !== "public") {
    return Response.json({ ignored: true });
  }

  const { data: keyRows, error: keyError } = await admin.rpc("get_supportdesk_vapid_keys");
  if (keyError || !keyRows?.[0]?.public_key || !keyRows?.[0]?.private_key) {
    console.error("VAPID key retrieval failed:", keyError?.message);
    return Response.json({ error: "Push signing keys are unavailable" }, { status: 500 });
  }
  webpush.setVapidDetails("https://support-desk-live.pages.dev", keyRows[0].public_key, keyRows[0].private_key);

  const { data: conversation, error: convError } = await admin
    .from("conversations")
    .select("id,subject,assigned_agent_id,status")
    .eq("id", event.record.conversation_id)
    .maybeSingle();
  if (convError) return Response.json({ error: convError.message }, { status: 500 });
  if (!conversation || conversation.status === "resolved") return Response.json({ ignored: true });

  let recipientIds: string[] = [];
  if (conversation.assigned_agent_id) {
    const { data } = await admin.from("staff_profiles")
      .select("user_id").eq("user_id", conversation.assigned_agent_id)
      .eq("active", true).limit(1);
    recipientIds = (data ?? []).map((x: { user_id: string }) => x.user_id);
  } else {
    const { data } = await admin.from("staff_profiles")
      .select("user_id").eq("active", true).in("role", ["admin", "supervisor"]);
    recipientIds = (data ?? []).map((x: { user_id: string }) => x.user_id);
  }
  if (!recipientIds.length) return Response.json({ sent: 0, reason: "No eligible staff recipients" });

  const { data: subscriptions, error: subError } = await admin
    .from("staff_push_subscriptions")
    .select("id,user_id,subscription")
    .in("user_id", recipientIds);
  if (subError) return Response.json({ error: subError.message }, { status: 500 });

  const notification = JSON.stringify({
    title: "New support message",
    body: "A customer sent a message. Open SupportDesk Live to reply.",
    url: "https://support-desk-live.pages.dev/"
  });

  let sent = 0;
  const staleIds: string[] = [];
  const results = await Promise.allSettled((subscriptions ?? []).map(async (row: any) => {
    try {
      await webpush.sendNotification(row.subscription, notification, { TTL: 60 });
      sent++;
    } catch (error: any) {
      if (error?.statusCode === 404 || error?.statusCode === 410) staleIds.push(row.id);
      else console.error("Push delivery failed:", error?.statusCode ?? error?.message);
    }
  }));
  if (staleIds.length) await admin.from("staff_push_subscriptions").delete().in("id", staleIds);
  return Response.json({ sent, attempted: results.length, stale_removed: staleIds.length });
});
