create table if not exists public.staff_push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  endpoint text not null unique,
  subscription jsonb not null,
  user_agent text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_success_at timestamptz
);
create index if not exists staff_push_subscriptions_user_id_idx
  on public.staff_push_subscriptions(user_id);
alter table public.staff_push_subscriptions enable row level security;
revoke all on public.staff_push_subscriptions from anon, authenticated;
grant select, insert, update, delete on public.staff_push_subscriptions to authenticated;

create policy staff_push_subscriptions_select_own
  on public.staff_push_subscriptions for select to authenticated
  using (user_id = (select auth.uid())
    and coalesce((select auth.jwt() ->> 'is_anonymous'), 'false') <> 'true'
    and (select public.is_staff()));
create policy staff_push_subscriptions_insert_own
  on public.staff_push_subscriptions for insert to authenticated
  with check (user_id = (select auth.uid())
    and coalesce((select auth.jwt() ->> 'is_anonymous'), 'false') <> 'true'
    and (select public.is_staff()));
create policy staff_push_subscriptions_update_own
  on public.staff_push_subscriptions for update to authenticated
  using (user_id = (select auth.uid())
    and coalesce((select auth.jwt() ->> 'is_anonymous'), 'false') <> 'true'
    and (select public.is_staff()))
  with check (user_id = (select auth.uid())
    and coalesce((select auth.jwt() ->> 'is_anonymous'), 'false') <> 'true'
    and (select public.is_staff()));
create policy staff_push_subscriptions_delete_own
  on public.staff_push_subscriptions for delete to authenticated
  using (user_id = (select auth.uid())
    and coalesce((select auth.jwt() ->> 'is_anonymous'), 'false') <> 'true'
    and (select public.is_staff()));
