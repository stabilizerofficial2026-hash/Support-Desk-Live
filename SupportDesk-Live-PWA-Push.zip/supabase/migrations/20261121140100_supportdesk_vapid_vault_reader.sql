-- VAPID key material is stored separately in Supabase Vault and is never committed.
drop function if exists public.get_supportdesk_vapid_keys();
create function public.get_supportdesk_vapid_keys()
returns table(public_key text, private_key text, hook_secret text)
language sql
security definer
set search_path = ''
as $$
  select
    (select ds.decrypted_secret from vault.decrypted_secrets ds where ds.name = 'supportdesk_vapid_public' limit 1),
    (select ds.decrypted_secret from vault.decrypted_secrets ds where ds.name = 'supportdesk_vapid_private' limit 1),
    (select ds.decrypted_secret from vault.decrypted_secrets ds where ds.name = 'supportdesk_push_hook_secret' limit 1);
$$;
revoke all on function public.get_supportdesk_vapid_keys() from public, anon, authenticated;
grant execute on function public.get_supportdesk_vapid_keys() to service_role;
